<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require('../db.php');
$database = DB::getInstance();

$results = $database->get_results("SELECT * FROM posts WHERE location like '%eagle rock%' or caption like '%eagle rock%'");
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Rock in Eagle Rock</title>
  <link rel="stylesheet" href="main.css">
</head>
<body>
  <h1>Rock in Eagle Rock</h1>
  <h2>Photos and ephemera of rock in Eagle Rock, Los Angeles</h2>
  <h3>By Joey Rose</h3>
  <p>Below are photos from Jorge N. Leal's rockarchivola Instagram page associated with Eagle Rock</p>
<?php
for ($j = 0; $j < count($results); $j++) {
?>
  <div>
  <a href = "<?=$results[$j]['insta_url']?>">
    <img src="<?=$results[$j]['path']?>" /><br />
  </a>
  </br>
    <h4><?=$results[$j]['title']?></h4>
    <p><?=$results[$j]['caption']?></p>
  </div>
  <?php
}
?>

</body>
</html>