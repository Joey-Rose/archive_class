<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require('../db.php');
$database = DB::getInstance();

$results = $database->get_results("SELECT * FROM posts WHERE post_id < 10");
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Liverpool’s Canonical Music Archive</title>
  <link rel="stylesheet" href="main.css">
</head>
<body>
  <h1>Liverpool’s Canonical Music Archive</h1>
  <h2>This is a web page archiving content related to the canonical music of Liverpool’s past</h2>
  <h3>By Joey Rose</h3>
  <p>"The Cavern Club, Eric’s Club, and Cream have taken on broader symbolic meanings as representative of entire musical genres and eras. These venues
provide landmarks that have come to represent significant moments in Liverpool’s
musical heritage, linked closely to the city’s social, cultural and economic landscapes during the 1960s, 1970s and 1990s. In a sense these three venues, or ‘three
graces’, represent points of magnetic density (Connell and Gibson 2003) that pull
heavily upon the social and physical fabric of the city’s landscape and character." - Brett Lashua, Sara Cohen, and John Schofield </p>
<?php
for ($j = 0; $j < count($results); $j++) {
?>
  <div>
  <a href = "<?=$results[$j]['insta_url']?>">
    <img src="<?=$results[$j]['path']?>" /><br />
  </a>
  </br>
    <h4><?=$results[$j]['title']?></h4>
    <p><?=$results[$j]['caption']?></p>
  </div>
  <?php
}
?>

</body>
</html>