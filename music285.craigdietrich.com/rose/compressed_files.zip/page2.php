<?php
$archive = array (
  array ("image" => "soda_stereo.jpg",
  "title" => "Soda Stereo",
   "desc" => "The famous Argentinian rock band that C.R.E.E. had connections with."
),
  array ("image" => "pacific_boulevard.jpg",
  "title" => "Pacific Boulevard",
   "desc" => "The street where C.R.E.E. first advirtised the extistence of their club with flyers."
),
  array ("image" => "recruitment_flyer.JPG",
  "title" => "Recruitment flyer",
   "desc" => "One of the first recuitment flyers created by Flora Rae Tapia and originally posted and distributed in 1989 along Pacific Boulevard in Huntington Park, CA."
),
  array ("image" => "pamphlet.JPG",
  "title" => "Pamphlet",
   "desc" => "Back of the Guateque II Pamphlet
   (1995) that lists the advocacy organizations
   included in an event."
),
  array ("image" => "philharmonic_hall.jpg",
  "title" => "The Philharmonic Hall",
   "desc" => "The concert hall included in Liverpool's 08' Sound City Map."
),
  array ("image" => "cream.jpg",
  "title" => "Cream",
   "desc" => "The nightclub that surged to popularity in the 1990s."
),
  array ("image" => "cavern_club.jpg",
  "title" => "Cavern Club",
   "desc" => "The wildly popular club in the 1960s where the Beatles played their first big show."
),
  array ("image" => "erics_club.jpg",
  "title" => "Eric's Club",
   "desc" => "The club that reached peak popularity in the 1970s."
  )
);
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>C.R.E.E. and Liverpool’s Canonical Music Archive</title>
  <link rel="stylesheet" href="page2.css">
</head>
<body>
  <h1>C.R.E.E. and Liverpool’s Canonical Music Archive</h1>
  <h2>This is a web page archiving content related to the C.R.E.E. and the canonical music of Liverpool’s past</h2>
  <h3>By Joey Rose</h3>
  <p>"In the 1980s, a group of Latinas became transnational music facilitators,
    Rock en Español advocates, and concert producers within and beyond South East Los Angeles
    by creating the Club Rock en Español (C.R.E.E.). Through C.R.E.E., these women
    connected cultural producers and youth across Latin America with the Latina/o residents of
    formerly white suburbs in Southern California." - Jorge N. Leal</p>
  <p>"The Cavern Club, Eric’s Club, and Cream have taken on broader symbolic meanings as representative of entire musical genres and eras. These venues
provide landmarks that have come to represent significant moments in Liverpool’s
musical heritage, linked closely to the city’s social, cultural and economic landscapes during the 1960s, 1970s and 1990s. In a sense these three venues, or ‘three
graces’, represent points of magnetic density (Connell and Gibson 2003) that pull
heavily upon the social and physical fabric of the city’s landscape and character." - Brett Lashua, Sara Cohen, and John Schofield </p>
<?php
for ($j = 0; $j < count($archive); $j++) {
?>
  <div>
  <img src="<?=$archive[$j]['image']?>" /><br />
    <h4><?=$archive[$j]['title']?></h4>
    <p><?=$archive[$j]['desc']?></p>
  </div>
  <?php
}
?>

</body>
</html>